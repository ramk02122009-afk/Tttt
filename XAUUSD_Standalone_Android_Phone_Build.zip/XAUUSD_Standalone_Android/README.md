# XAUUSD INR Gold Terminal — Standalone Android project

This project packages the user's uploaded `app.py` and `index.html` into an Android app.
It runs the FastAPI/Pyth backend inside the APK using Chaquopy, then displays the UI in
an Android WebView pointed at the app's own loopback server (`127.0.0.1:8765`).

## Included behavior from the supplied files
- Pyth Lazer WebSocket feed and locally archived candles
- 1m / 5m / 15m / 1h chart
- Paper BUY / SELL orders
- Reserved margin, equity, floating and realized P&L
- Chart-drag TP/SL for selected open trades
- Tick-based TP/SL and margin close
- SQLite paper-trading database

## Build APK using only an Android phone (GitHub Actions)
1. Sign in to GitHub in your phone browser and create a new **private** repository.
2. Extract this ZIP using your phone's Files app. Upload the contents of the `XAUUSD_Standalone_Android` folder to the repository root (make sure the `.github/workflows/build-apk.yml` file is included).
3. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
4. Select **Build Gold Terminal APK** and tap **Run workflow**.
5. Wait for the run to finish. Open the completed run, scroll to **Artifacts**, and download `Gold-Terminal-debug-APK`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Allow your browser/files app to install unknown apps if Android asks.

The workflow builds the APK on GitHub's cloud runner, so you do not need Android Studio, a computer, Gradle, or Pydroid on your phone. Internet is required for the cloud build and for live market data.

## Build requirements (if using a computer instead)
- Android Studio (current stable)
- Android SDK Platform 36
- JDK 17
- Internet during the first Gradle sync/build (Gradle, Chaquopy and Python wheels are downloaded)

## Build APK
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the `XAUUSD_Standalone_Android` folder.
3. Allow Gradle sync and install any requested SDK Platform 36.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to the Android device and install it. If Android asks, allow installation from that source.

## First launch
- Enter the Pyth Lazer API key in the app's API KEY dialog.
- The key is kept in the app's private SharedPreferences and private `.env` file. It is not bundled into the APK.
- The app starts its Python backend itself; do not start Pydroid, Uvicorn, or a terminal.
- Keep internet enabled for the Pyth feed and USD/INR rate.

## Data and privacy
The SQLite database and `.env` are stored in the app's private internal files directory:
`/data/user/0/com.ram.goldterminal/files/paper_trader/`.
Android app data is removed if the app is uninstalled unless separately backed up.
Never upload or share the `.env` file or API key.

## Notes / limitations
- This is a paper-trading app only. It does not connect to a broker or place real-money orders.
- The supplied chart library is still loaded from its existing unpkg CDN URL, so the chart library needs internet access at page load.
- Android may pause network activity when the app is backgrounded or the device enters battery-saving mode. Keep the app in the foreground for continuous tick processing.
- This generated project is an Android Studio source project, not a prebuilt APK. A full Android SDK/Gradle build environment is not available in this workspace.

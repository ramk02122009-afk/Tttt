package com.ram.goldterminal

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.File

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("gold_terminal_private", MODE_PRIVATE) }
    private val serverUrl = "http://127.0.0.1:8765/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildShell()
        val savedKey = prefs.getString("pyth_api_key", "") ?: ""
        if (savedKey.isBlank()) askForApiKey()
        else startEmbeddedBackend(savedKey)
    }

    private fun buildShell() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 8, 10, 8)
            setBackgroundColor(Color.rgb(18, 29, 45))
        }
        val title = TextView(this).apply {
            text = "GOLD TERMINAL  ·  XAUUSD INR"
            textSize = 16f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val keyButton = Button(this).apply {
            text = "API KEY"
            setOnClickListener { askForApiKey() }
        }
        toolbar.addView(title)
        toolbar.addView(keyButton)
        status = TextView(this).apply {
            text = "Starting embedded trading engine…"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(14, 5, 14, 5)
        }
        progress = ProgressBar(this).apply { isIndeterminate = true }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(Color.rgb(11, 18, 32))
        }
        outer.addView(toolbar)
        outer.addView(status)
        outer.addView(progress)
        outer.addView(webView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(outer)
    }

    private fun askForApiKey() {
        val input = EditText(this).apply {
            hint = "Pyth API key"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("pyth_api_key", "") ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("Connect to Pyth")
            .setMessage("Enter your Pyth Lazer API key. It is stored only in this app's private storage. Do not share it.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Save & connect") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isBlank()) {
                    Toast.makeText(this, "API key is required for live prices.", Toast.LENGTH_LONG).show()
                    askForApiKey()
                } else {
                    prefs.edit().putString("pyth_api_key", key).apply()
                    startEmbeddedBackend(key)
                }
            }
            .setNegativeButton("Exit") { _, _ -> finish() }
            .show()
    }

    private fun startEmbeddedBackend(apiKey: String) {
        status.text = "Starting embedded Python + FastAPI…"
        progress.visibility = android.view.View.VISIBLE
        Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val home = filesDir.absolutePath + "/paper_trader"
                val staticDir = File(home, "static")
                staticDir.mkdirs()
                assets.open("static/index.html").use { input ->
                    File(staticDir, "index.html").outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                Python.getInstance().getModule("launcher")
                    .callAttr("start_server", home, apiKey)

                var ready = false
                var lastError = ""
                repeat(60) {
                    if (!ready) {
                        try {
                            val conn = URL(serverUrl).openConnection() as HttpURLConnection
                            conn.connectTimeout = 1000
                            conn.readTimeout = 1000
                            conn.connect()
                            ready = conn.responseCode == 200
                            conn.disconnect()
                        } catch (e: Exception) {
                            lastError = e.message ?: "Waiting for local server"
                        }
                        if (!ready) Thread.sleep(500)
                    }
                }
                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    if (ready) {
                        status.text = "Embedded engine ready · Pyth live connection starting"
                        webView.loadUrl(serverUrl)
                    } else {
                        status.text = "Engine did not start: $lastError"
                        Toast.makeText(this, "Could not start local trading engine.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = android.view.View.GONE
                    status.text = "Startup error: ${e.message}"
                    Toast.makeText(this, "Startup error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}

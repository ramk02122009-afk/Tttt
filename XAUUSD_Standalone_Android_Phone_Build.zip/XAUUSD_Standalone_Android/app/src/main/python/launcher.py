import os
import threading
from pathlib import Path

_server_started = False
_server_lock = threading.Lock()

def start_server(home, api_key):
    global _server_started
    with _server_lock:
        if _server_started:
            return "already_started"

        home = Path(home)
        home.mkdir(parents=True, exist_ok=True)
        (home / "static").mkdir(parents=True, exist_ok=True)

        # The Android app stores this file only in its private internal directory.
        env_path = home / ".env"
        env_path.write_text(
            "PYTH_API_KEY=" + api_key.replace("\n", "").replace("\r", "") + "\n",
            encoding="utf-8"
        )
        os.environ["PAPER_TRADER_HOME"] = str(home)
        os.environ["PYTH_API_KEY"] = api_key.strip()
        os.chdir(str(home))

        import app as trading_app
        import uvicorn

        def run():
            uvicorn.run(
                trading_app.app,
                host="127.0.0.1",
                port=8765,
                log_level="warning",
                access_log=False
            )

        threading.Thread(target=run, name="paper-trader-api", daemon=True).start()
        _server_started = True
        return "started"

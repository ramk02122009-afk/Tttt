import asyncio, json, os, sqlite3, time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

import httpx
import websockets
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(os.getenv("PAPER_TRADER_HOME", str(Path(__file__).parent)))
ROOT.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / ".env")
DB = ROOT / "paper_trading.db"
KEY = os.getenv("PYTH_API_KEY", "").strip()
FEED_ID = 346
FEED_SYMBOL = "Metal.XAU/USD"
FEED_ID_HEX = "0x765d2ba906dbc32ca17cc11f5310a89e9ee1f6420508c63861f2f8ba4ee34bb2"
START_BALANCE = float(os.getenv("STARTING_BALANCE_INR", "10000"))
# Paper leverage only: 100x reserves 1% of the position notional.
PAPER_LEVERAGE = max(1.0, float(os.getenv("PAPER_LEVERAGE", "100")))
FX_OVERRIDE = os.getenv("USD_INR_OVERRIDE", "").strip()
PYTH_WS = "wss://pyth-lazer-0.dourolabs.app/v1/stream"
PYTH_HISTORY = "https://pyth.dourolabs.app/v1/real_time/history"

state = {"price": None, "confidence": None, "publish_time": None,
         "received_at": None, "feed_status": "disconnected", "fx": None,
         "fx_updated": None, "last_error": None}
clients = set()
db_lock = asyncio.Lock()

def connect_db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with connect_db() as c:
        c.executescript(f"""
        CREATE TABLE IF NOT EXISTS account(id INTEGER PRIMARY KEY CHECK(id=1), balance REAL NOT NULL);
        INSERT OR IGNORE INTO account(id,balance) VALUES(1,{START_BALANCE});
        CREATE TABLE IF NOT EXISTS positions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, side TEXT NOT NULL, lots REAL NOT NULL,
          entry REAL NOT NULL, tp REAL, sl REAL, opened_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS trades(
          id INTEGER PRIMARY KEY AUTOINCREMENT, side TEXT NOT NULL, lots REAL NOT NULL,
          entry REAL NOT NULL, exit REAL NOT NULL, pnl_inr REAL NOT NULL,
          reason TEXT NOT NULL, opened_at TEXT NOT NULL, closed_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS candles(
          resolution INTEGER NOT NULL, ts INTEGER NOT NULL, o REAL NOT NULL,
          h REAL NOT NULL, l REAL NOT NULL, c REAL NOT NULL,
          PRIMARY KEY(resolution,ts));
        CREATE TABLE IF NOT EXISTS ticks(ts INTEGER PRIMARY KEY, price REAL NOT NULL);
        """)
        # Upgrade existing databases without deleting the user's paper-trading history.
        columns = {row["name"] for row in c.execute("PRAGMA table_info(positions)")}
        if "margin" not in columns:
            c.execute("ALTER TABLE positions ADD COLUMN margin REAL NOT NULL DEFAULT 0")
        c.execute("UPDATE account SET balance=? WHERE id=1 AND balance IS NULL", (START_BALANCE,))

def iso_now():
    return datetime.now(timezone.utc).isoformat()

def get_balance():
    with connect_db() as c:
        return float(c.execute("SELECT balance FROM account WHERE id=1").fetchone()["balance"])

def get_positions():
    with connect_db() as c:
        return [dict(x) for x in c.execute("SELECT * FROM positions ORDER BY id DESC")]

def get_history(limit=200):
    with connect_db() as c:
        return [dict(x) for x in c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,))]

async def get_fx():
    if FX_OVERRIDE:
        try: return float(FX_OVERRIDE)
        except ValueError: pass
    if state["fx"] and time.time() - (state["fx_updated"] or 0) < 3600:
        return state["fx"]
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.get("https://open.er-api.com/v6/latest/USD")
            r.raise_for_status()
            rate = float(r.json()["rates"]["INR"])
            state["fx"], state["fx_updated"] = rate, time.time()
            return rate
    except Exception:
        return state["fx"] or 0.0

def unrealized(position, mark, fx):
    direction = 1 if position["side"] == "BUY" else -1
    return (mark - position["entry"]) * direction * position["lots"] * 100 * fx

async def broadcast():
    payload = await snapshot()
    dead = []
    for ws in list(clients):
        try: await ws.send_json(payload)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)

async def snapshot():
    fx = await get_fx()
    price = state["price"]
    positions = get_positions()
    floating = sum(unrealized(p, price, fx) for p in positions) if price and fx else 0
    used_margin = sum(float(p.get("margin") or 0) for p in positions)
    available_balance = get_balance()
    equity = max(0.0, available_balance + used_margin + floating)
    return {
      **state, "fx": fx, "balance": available_balance, "used_margin": used_margin,
      "free_margin": max(0.0, equity - used_margin), "equity": equity,
      "floating_pnl": floating, "positions": positions, "history": get_history(),
      "paper_leverage": PAPER_LEVERAGE
    }

async def update_candle(price, publish_time):
    ts = int(publish_time or time.time())
    with connect_db() as c:
        c.execute("INSERT OR REPLACE INTO ticks(ts,price) VALUES(?,?)", (ts, price))
        # Keep local tick archive bounded to 30 days.
        c.execute("DELETE FROM ticks WHERE ts < ?", (ts - 30*86400,))
        minute = ts - ts % 60
        row = c.execute("SELECT * FROM candles WHERE resolution=1 AND ts=?", (minute,)).fetchone()
        if row:
            o,h,l = row["o"], max(row["h"],price), min(row["l"],price)
        else:
            prev = c.execute("SELECT c FROM candles WHERE resolution=1 ORDER BY ts DESC LIMIT 1").fetchone()
            o = prev["c"] if prev else price
            h,l = max(o,price), min(o,price)
        c.execute("INSERT OR REPLACE INTO candles VALUES(1,?,?,?,?,?)", (minute,o,h,l,price))
        c.execute("DELETE FROM candles WHERE resolution=1 AND ts < ?", (ts-30*86400,))

async def process_price(price, confidence, publish_time):
    state.update(price=price, confidence=confidence, publish_time=publish_time,
                 received_at=time.time(), feed_status="live", last_error=None)
    await update_candle(price, publish_time)
    fx = await get_fx()
    if fx > 0:
        with connect_db() as c:
            rows = c.execute("SELECT * FROM positions").fetchall()
            for p in rows:
                pnl = unrealized(dict(p), price, fx)
                hit = None
                # Check protective orders on every received tick.
                if p["sl"] is not None and ((p["side"]=="BUY" and price <= p["sl"]) or (p["side"]=="SELL" and price >= p["sl"])):
                    hit = "Stop loss"
                elif p["tp"] is not None and ((p["side"]=="BUY" and price >= p["tp"]) or (p["side"]=="SELL" and price <= p["tp"])):
                    hit = "Take profit"
                margin = float(p["margin"] or 0)
                if hit is None and margin > 0 and pnl <= -margin:
                    hit = "Margin close"
                    pnl = -margin
                if hit:
                    # A paper position can never lose more than its reserved margin.
                    if margin > 0:
                        pnl = max(pnl, -margin)
                    release = max(0.0, margin + pnl)
                    c.execute("UPDATE account SET balance=MAX(0,balance+?) WHERE id=1", (release,))
                    c.execute("""INSERT INTO trades(side,lots,entry,exit,pnl_inr,reason,opened_at,closed_at)
                                 VALUES(?,?,?,?,?,?,?,?)""",
                              (p["side"],p["lots"],p["entry"],price,pnl,hit,p["opened_at"],iso_now()))
                    c.execute("DELETE FROM positions WHERE id=?", (p["id"],))
    await broadcast()

async def pyth_stream():
    if not KEY:
        state.update(feed_status="needs_api_key", last_error="Add PYTH_API_KEY to .env and restart.")
        return
    delay = 2
    while True:
        try:
            async with websockets.connect(
                PYTH_WS, subprotocols=["pyth-lazer-auth", KEY],
                ping_interval=20, ping_timeout=20, close_timeout=5
            ) as ws:
                await ws.send(json.dumps({
                  "type":"subscribe","subscriptionId":1,"channel":"fixed_rate@200ms",
                  "priceFeedIds":[FEED_ID],
                  "properties":["price","exponent","confidence","feedUpdateTimestamp"],
                  "formats":[],"deliveryFormat":"json","parsed":True
                }))
                state.update(feed_status="connecting", last_error=None)
                delay = 2
                async for raw in ws:
                    msg = json.loads(raw)
                    if msg.get("type") in ("error","subscriptionError"):
                        raise RuntimeError(msg.get("error","Pyth subscription failed"))
                    if msg.get("type") == "streamUpdated":
                        feeds = msg.get("parsed",{}).get("priceFeeds",[])
                        for f in feeds:
                            if int(f.get("priceFeedId",-1)) != FEED_ID: continue
                            exp = int(f.get("exponent",0))
                            px = float(f["price"]) * (10 ** exp)
                            conf = float(f.get("confidence",0)) * (10 ** exp)
                            ts_us = int(f.get("feedUpdateTimestamp") or msg.get("parsed",{}).get("timestampUs") or time.time()*1e6)
                            await process_price(px, conf, ts_us//1_000_000)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            state.update(feed_status="disconnected", last_error=str(e))
            await broadcast()
            await asyncio.sleep(delay)
            delay = min(delay*2,30)

@asynccontextmanager
async def lifespan(app):
    init_db()
    task = asyncio.create_task(pyth_stream())
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass

app = FastAPI(title="XAUUSD INR Paper Trader", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=ROOT/"static"), name="static")

@app.get("/")
async def home(): return FileResponse(ROOT/"static"/"index.html")

@app.get("/api/state")
async def api_state(): return await snapshot()


@app.get("/api/history-candles")
async def history_candles(resolution: str = "1", hours: int = 24):
    """Return candles archived locally from the live Pyth price stream.

    This deliberately avoids the separate Pyth history/symbol lookup API,
    which was returning `symbol not found` for this account/feed. The first
    run starts building candles as soon as live ticks arrive.
    """
    try:
        minutes = int(resolution)
    except (TypeError, ValueError):
        raise HTTPException(400, "Resolution must be 1, 5, 15, or 60 minutes.")
    if minutes not in (1, 5, 15, 60):
        raise HTTPException(400, "Resolution must be 1, 5, 15, or 60 minutes.")

    end = int(time.time())
    start = end - max(1, min(int(hours), 720)) * 3600
    with connect_db() as c:
        rows = c.execute(
            "SELECT ts,o,h,l,c FROM candles WHERE resolution=1 AND ts>=? ORDER BY ts ASC",
            (start,)
        ).fetchall()

    # Aggregate archived 1-minute candles into the selected chart timeframe.
    grouped = {}
    interval = minutes * 60
    for row in rows:
        bucket = int(row["ts"]) - (int(row["ts"]) % interval)
        if bucket not in grouped:
            grouped[bucket] = {
                "time": bucket,
                "open": float(row["o"]),
                "high": float(row["h"]),
                "low": float(row["l"]),
                "close": float(row["c"]),
            }
        else:
            candle = grouped[bucket]
            candle["high"] = max(candle["high"], float(row["h"]))
            candle["low"] = min(candle["low"], float(row["l"]))
            candle["close"] = float(row["c"])
    return list(grouped.values())


class Order(BaseModel):
    side: str
    lots: float = Field(ge=0.01, le=10)
    tp: float | None = Field(default=None, gt=0)
    sl: float | None = Field(default=None, gt=0)

@app.post("/api/order")
async def place_order(order: Order):
    if state["price"] is None or state["feed_status"] != "live" or time.time()-(state["received_at"] or 0)>5:
        raise HTTPException(503,"Live XAUUSD feed is not fresh. New orders are disabled.")
    side=order.side.upper()
    if side not in ("BUY","SELL"): raise HTTPException(400,"Side must be BUY or SELL.")
    p=state["price"]
    if order.tp is not None and ((side=="BUY" and order.tp<=p) or (side=="SELL" and order.tp>=p)):
        raise HTTPException(400,"Take profit must be beyond entry in the trade direction.")
    if order.sl is not None and ((side=="BUY" and order.sl>=p) or (side=="SELL" and order.sl<=p)):
        raise HTTPException(400,"Stop loss must be beyond entry against the trade direction.")
    fx = await get_fx()
    if fx <= 0: raise HTTPException(503,"USD/INR rate unavailable; order rejected.")
    margin = (p * 100.0 * order.lots * fx) / PAPER_LEVERAGE
    with connect_db() as c:
        c.execute("BEGIN IMMEDIATE")
        balance = float(c.execute("SELECT balance FROM account WHERE id=1").fetchone()["balance"])
        if margin > balance:
            raise HTTPException(400, f"Insufficient available balance. Required margin: ₹{margin:,.2f}; available: ₹{balance:,.2f}. Reduce lot size.")
        c.execute("UPDATE account SET balance=balance-? WHERE id=1", (margin,))
        cur=c.execute("INSERT INTO positions(side,lots,entry,tp,sl,opened_at,margin) VALUES(?,?,?,?,?,?,?)",
                      (side,order.lots,p,order.tp,order.sl,iso_now(),margin))
        pid=cur.lastrowid
    await broadcast()
    return {"id":pid,"entry":p,"side":side,"margin":margin,"available_balance":get_balance()}


class ProtectionUpdate(BaseModel):
    # Both keys are sent by the UI. null removes that protection level.
    tp: float | None = Field(default=None, gt=0)
    sl: float | None = Field(default=None, gt=0)

@app.post("/api/position/{position_id}/protection")
async def update_position_protection(position_id: int, update: ProtectionUpdate):
    """Change or remove TP/SL on an already-open paper position."""
    price = state["price"]
    if price is None or state["feed_status"] != "live" or time.time() - (state["received_at"] or 0) > 5:
        raise HTTPException(503, "Live price is not fresh. TP/SL was not changed.")

    with connect_db() as c:
        c.execute("BEGIN IMMEDIATE")
        row = c.execute("SELECT * FROM positions WHERE id=?", (position_id,)).fetchone()
        if row is None:
            raise HTTPException(404, "This position is no longer open.")

        side = row["side"]
        tp, sl = update.tp, update.sl

        # Validate new levels against the CURRENT market price, not the entry price.
        if tp is not None and ((side == "BUY" and tp <= price) or (side == "SELL" and tp >= price)):
            raise HTTPException(400, f"TP must be beyond the current price ({price:.2f}) in the {side} direction.")
        if sl is not None and ((side == "BUY" and sl >= price) or (side == "SELL" and sl <= price)):
            raise HTTPException(400, f"SL must be beyond the current price ({price:.2f}) against the {side} direction.")

        c.execute("UPDATE positions SET tp=?, sl=? WHERE id=?", (tp, sl, position_id))

    await broadcast()
    return {"updated": True, "id": position_id, "tp": tp, "sl": sl, "current_price": price}

@app.post("/api/close/{position_id}")
async def close_order(position_id:int):
    p=state["price"]; fx=await get_fx()
    if p is None or fx<=0: raise HTTPException(503,"No current price/FX conversion available.")
    with connect_db() as c:
        c.execute("BEGIN IMMEDIATE")
        row=c.execute("SELECT * FROM positions WHERE id=?",(position_id,)).fetchone()
        if not row: raise HTTPException(404,"Position not found.")
        pnl=unrealized(dict(row),p,fx)
        margin=float(row["margin"] or 0)
        if margin > 0: pnl=max(pnl,-margin)
        release=max(0.0,margin+pnl)
        c.execute("UPDATE account SET balance=MAX(0,balance+?) WHERE id=1",(release,))
        c.execute("""INSERT INTO trades(side,lots,entry,exit,pnl_inr,reason,opened_at,closed_at)
                     VALUES(?,?,?,?,?,?,?,?)""",
                  (row["side"],row["lots"],row["entry"],p,pnl,"Manual close",row["opened_at"],iso_now()))
        c.execute("DELETE FROM positions WHERE id=?",(position_id,))
    await broadcast()
    return {"closed":True,"pnl_inr":pnl,"released_margin":margin,"balance":get_balance()}

@app.post("/api/reset")
async def reset():
    with connect_db() as c:
        c.execute("DELETE FROM positions");c.execute("DELETE FROM trades")
        c.execute("UPDATE account SET balance=? WHERE id=1",(START_BALANCE,))
    await broadcast()
    return {"balance":START_BALANCE}

@app.websocket("/ws")
async def websocket_endpoint(ws:WebSocket):
    await ws.accept();clients.add(ws)
    try:
        await ws.send_json(await snapshot())
        while True: await ws.receive_text()
    except WebSocketDisconnect: pass
    finally: clients.discard(ws)

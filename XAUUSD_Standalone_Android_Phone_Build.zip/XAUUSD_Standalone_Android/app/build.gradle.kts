plugins {
    id("com.android.application")
    id("com.chaquo.python")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ram.goldterminal"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.ram.goldterminal"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*"
            )
        }
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        pip {
            install("fastapi==0.115.12")
            install("uvicorn==0.34.2")
            install("websockets==13.1")
            install("httpx==0.28.1")
            install("python-dotenv==1.1.0")
            install("pydantic==2.11.4")
        }
    }
}
